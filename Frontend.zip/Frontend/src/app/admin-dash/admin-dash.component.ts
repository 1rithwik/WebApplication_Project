import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-dash',
  standalone: true,
  imports: [],
  templateUrl: './admin-dash.component.html',
  styleUrl: './admin-dash.component.css'
})
export class AdminDashComponent {

}
