import { Component } from '@angular/core';

@Component({
  selector: 'app-tire-admin',
  standalone: true,
  imports: [],
  templateUrl: './tire-admin.component.html',
  styleUrl: './tire-admin.component.css'
})
export class TireAdminComponent {

}
